export interface IBase {
  _id: string;
  created_at: string;
  updatedAt: string;
  __v: string;
}
